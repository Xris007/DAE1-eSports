
--Eliminar
CREATE PROCEDURE EliminarTorneo
@IdTorneo INT
AS
DELETE FROM TORNEO WHERE IdTorneo = @IdTorneo
go

