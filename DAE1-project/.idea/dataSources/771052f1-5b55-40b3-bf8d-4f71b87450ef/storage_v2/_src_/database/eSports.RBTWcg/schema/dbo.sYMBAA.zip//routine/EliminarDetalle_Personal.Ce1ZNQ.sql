
--Eliminar
CREATE PROCEDURE EliminarDetalle_Personal
@IdPersonal int, @IdTorneo int
AS
DELETE FROM DETALLE_PERSONAL WHERE IdPersonal = @IdPersonal AND IdTorneo = @IdTorneo
go

