
--5. Jugador
--Listar
CREATE PROCEDURE ListarJugador
AS
SELECT * FROM JUGADOR
go

