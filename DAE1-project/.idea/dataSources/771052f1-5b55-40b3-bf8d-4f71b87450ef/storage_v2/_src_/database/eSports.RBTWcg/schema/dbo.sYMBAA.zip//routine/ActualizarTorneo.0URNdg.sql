
--Actualizar 
CREATE PROCEDURE ActualizarTorneo
    @IdTorneo int, @NomTorneo varchar(30) = NULL, @OrgTorneo varchar(30) = NULL, @PaisTorneo varchar(30) = NULL, @LugarTorneo varchar(30) = NULL, @FechaInicioTorneo datetime = NULL, @FechaFinTorneo datetime = NULL, @IdJuego int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE TORNEO
    SET NomTorneo=ISNULL(@NomTorneo,NomTorneo), 
        OrgTorneo=ISNULL(@OrgTorneo,OrgTorneo), 
        PaisTorneo=ISNULL(@PaisTorneo, PaisTorneo),
		LugarTorneo=ISNULL(@LugarTorneo, LugarTorneo),
		FechaInicioTorneo=ISNULL(@FechaInicioTorneo, FechaInicioTorneo),
		FechaFinTorneo=ISNULL(@FechaFinTorneo, FechaFinTorneo),
		IdJuego=ISNULL(@IdJuego, IdJuego)
    WHERE IdTorneo=@IdTorneo
END

EXEC ActualizarTorneo @IDTORNEO = 1, @LUGARTORNEO = 'USA'
go

