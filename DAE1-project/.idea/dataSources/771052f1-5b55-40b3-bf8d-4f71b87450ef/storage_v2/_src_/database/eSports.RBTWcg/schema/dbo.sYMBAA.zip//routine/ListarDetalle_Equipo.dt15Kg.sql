
--7. Detalle_Equipo 
--Listar
CREATE PROCEDURE ListarDetalle_Equipo 
AS
SELECT * FROM DETALLE_EQUIPO
go

