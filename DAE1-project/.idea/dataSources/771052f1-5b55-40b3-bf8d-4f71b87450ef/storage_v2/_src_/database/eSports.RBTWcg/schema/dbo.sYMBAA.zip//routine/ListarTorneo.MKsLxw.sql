
--2. Torneo
--Listar
CREATE PROCEDURE ListarTorneo AS
SELECT * FROM TORNEO
go

