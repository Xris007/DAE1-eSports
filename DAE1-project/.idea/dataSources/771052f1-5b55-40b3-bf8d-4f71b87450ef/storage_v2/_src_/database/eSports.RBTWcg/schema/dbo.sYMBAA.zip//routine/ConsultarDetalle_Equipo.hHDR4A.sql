
--Consultar
CREATE PROCEDURE ConsultarDetalle_Equipo
@IdEquipo INT, @IdTorneo INT
AS
SELECT * FROM DETALLE_EQUIPO WHERE IdEquipo = @IdEquipo AND IdTorneo = @IdTorneo
go

