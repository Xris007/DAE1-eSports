
--Insertar
CREATE PROCEDURE InsertarJuego
@IdJuego int, @NomJuego varchar(30), @DesaJuego varchar(30), @FechaJuego datetime, @GeneJuego varchar(20)
AS
Insert into JUEGO values (@IdJuego,@NomJuego,@DesaJuego,@FechaJuego,@GeneJuego)
go

