
--Actualizar
CREATE PROCEDURE ActualizarJugador
	@IdJugador int, @ApeJugador varchar(30) = NULL, @NomJugador varchar(30) = NULL,@NickJugador varchar(30) = NULL,@EdadJugador int = NULL, @PaisJugador varchar(30) = NULL,@CapJugador char(1) = NULL,@IdEquipo int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE JUGADOR
    SET ApeJugador=ISNULL(@ApeJugador,ApeJugador), 
        NomJugador=ISNULL(@NomJugador,NomJugador),
		NickJugador=ISNULL(@NickJugador,NickJugador),
		EdadJugador=ISNULL(@EdadJugador,EdadJugador),
		PaisJugador=ISNULL(@PaisJugador,PaisJugador),
		CapJugador=ISNULL(@CapJugador,CapJugador),
		IdEquipo=ISNULL(@IdEquipo,IdEquipo)
    WHERE IdJugador=@IdJugador
END
go

