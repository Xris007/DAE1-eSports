
--Consultar
CREATE PROCEDURE ConsultarJugador
@IdJugador INT
AS
SELECT * FROM JUGADOR WHERE IdJugador = @IdJugador
go

