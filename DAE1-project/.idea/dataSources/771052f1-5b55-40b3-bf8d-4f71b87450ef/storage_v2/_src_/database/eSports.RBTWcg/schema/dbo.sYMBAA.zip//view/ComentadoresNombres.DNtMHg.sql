---------------------------------
-------Creación de Views---------

---1. Datos personales de comentadores
create view dbo.ComentadoresNombres
as
select PERSONAL.ApePersonal + ', ' + PERSONAL.NomPersonal as [Apellidos y Nombres], PERSONAL.PaisPersonal as País, 
PERSONAL.CargoPersonal as Cargo
from PERSONAL
where CargoPersonal = 'Comentador'
go

