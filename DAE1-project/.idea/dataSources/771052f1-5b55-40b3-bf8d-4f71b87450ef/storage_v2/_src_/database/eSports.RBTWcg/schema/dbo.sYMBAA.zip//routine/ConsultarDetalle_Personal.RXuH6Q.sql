
--Consultar
CREATE PROCEDURE ConsultarDetalle_Personal
@IdPersonal INT, @IdTorneo INT
AS
SELECT * FROM DETALLE_PERSONAL WHERE IdPersonal = @IdPersonal AND IdTorneo = @IdTorneo
go

