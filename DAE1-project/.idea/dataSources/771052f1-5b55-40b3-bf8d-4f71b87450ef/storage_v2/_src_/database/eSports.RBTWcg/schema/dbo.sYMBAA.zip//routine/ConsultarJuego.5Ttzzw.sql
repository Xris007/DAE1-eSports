
--Consultar
CREATE PROCEDURE ConsultarJuego
@IdJuego INT
AS
SELECT * FROM JUEGO WHERE IdJuego = @IdJuego

