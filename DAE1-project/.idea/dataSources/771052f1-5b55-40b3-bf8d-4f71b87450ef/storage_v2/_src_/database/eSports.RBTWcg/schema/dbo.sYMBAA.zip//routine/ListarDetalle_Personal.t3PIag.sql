
--6. Detalle_Personal
--Listar
CREATE PROCEDURE ListarDetalle_Personal
AS
SELECT * FROM DETALLE_PERSONAL
go

