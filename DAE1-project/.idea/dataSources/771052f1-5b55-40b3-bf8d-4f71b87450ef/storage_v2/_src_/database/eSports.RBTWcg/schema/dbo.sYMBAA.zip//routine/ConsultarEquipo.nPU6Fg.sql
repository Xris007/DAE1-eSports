
--Consultar
CREATE PROCEDURE ConsultarEquipo
@IdEquipo INT
AS
SELECT * FROM EQUIPO WHERE IdEquipo = @IdEquipo
go

