
---3. lista de todo el personal que sea de Reino Unido.
create view dbo.PersonalUK
as
select PERSONAL.ApePersonal+ ', ' + PERSONAL.NomPersonal as [Apellidos y Nombres], PERSONAL.PaisPersonal as País, PERSONAL.CargoPersonal as Cargo
from PERSONAL
where PaisPersonal like '%reino%'
go

