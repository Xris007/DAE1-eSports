
--Actualizar
CREATE PROCEDURE ActualizarDetalle_Equipo 
	@IdEquipo int, @IdTorneo int, @Victorias int = NULL, @Derrotas int = NULL, @Puesto int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE DETALLE_EQUIPO
    SET Victorias=ISNULL(@Victorias,Victorias), 
        Derrotas=ISNULL(@Derrotas,Derrotas),
		Puesto=ISNULL(@Puesto,Puesto)
    WHERE IdEquipo=@IdEquipo AND IdTorneo = @IdTorneo
END
go

