
--Insertar
CREATE PROCEDURE InsertarDetalle_Equipo 
@IdEquipo int, @IdTorneo int, @Victorias int, @Derrotas int, @Puesto int
AS
Insert into DETALLE_EQUIPO values (@IdEquipo,@IdTorneo,@Victorias,@Derrotas,@Puesto)
go

