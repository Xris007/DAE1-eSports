
--Eliminar
CREATE PROCEDURE EliminarJugador
@IdJugador INT
AS
DELETE FROM JUGADOR WHERE IdJugador = @IdJugador
go

