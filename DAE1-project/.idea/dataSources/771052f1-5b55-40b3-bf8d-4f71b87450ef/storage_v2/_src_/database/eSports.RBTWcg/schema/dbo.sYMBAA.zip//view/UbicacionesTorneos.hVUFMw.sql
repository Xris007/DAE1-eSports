
---2. lista de ubicaciones en donde se han realizado los torneos
create view dbo.UbicacionesTorneos
as
select TORNEO.NomTorneo as [Nombre de Torneo], TORNEO.PaisTorneo as País, TORNEO.LugarTorneo as Lugar
from TORNEO
go

