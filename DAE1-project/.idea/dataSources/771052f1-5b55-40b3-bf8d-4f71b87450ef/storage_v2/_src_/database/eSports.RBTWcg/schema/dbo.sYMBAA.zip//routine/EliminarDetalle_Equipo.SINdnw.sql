
--Eliminar
CREATE PROCEDURE EliminarDetalle_Equipo
@IdEquipo int, @IdTorneo int
AS
DELETE FROM DETALLE_EQUIPO WHERE IdEquipo = @IdEquipo AND IdTorneo = @IdTorneo
go

