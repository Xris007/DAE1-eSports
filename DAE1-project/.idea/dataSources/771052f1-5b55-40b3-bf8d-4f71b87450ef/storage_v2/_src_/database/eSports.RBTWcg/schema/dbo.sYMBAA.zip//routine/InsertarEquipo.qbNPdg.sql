
--Insertar
CREATE PROCEDURE InsertarEquipo
@IdEquipo int, @NomEquipo varchar(30), @PaisEquipo varchar(30)
AS
Insert into EQUIPO values (@IdEquipo,@NomEquipo,@PaisEquipo)
go

