
--Actualizar
CREATE PROCEDURE ActualizarPersonal
    @IdPersonal INT, @ApePersonal VARCHAR(30) = NULL, @NomPersonal varchar(30) = NULL, @PaisPersonal varchar(30) = NULL, @CargoPersonal varchar(30) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE PERSONAL
    SET NomPersonal=ISNULL(@NomPersonal,NomPersonal), 
        ApePersonal=ISNULL(@ApePersonal,ApePersonal), 
        PaisPersonal=ISNULL(@PaisPersonal, PaisPersonal),
		CargoPersonal=ISNULL(@CargoPersonal, CargoPersonal)
    WHERE IdPersonal=@IdPersonal
END

EXEC ActualizarPersonal @IDPERSONAL = 1, @PaisPersonal = 'USA'
go

