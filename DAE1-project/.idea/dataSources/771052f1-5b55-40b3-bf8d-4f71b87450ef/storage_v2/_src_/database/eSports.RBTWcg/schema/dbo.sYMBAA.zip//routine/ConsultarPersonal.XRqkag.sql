
--Consultar
CREATE PROCEDURE ConsultarPersonal
@IdPersonal INT
AS
SELECT * FROM PERSONAL WHERE IdPersonal = @IdPersonal
go

