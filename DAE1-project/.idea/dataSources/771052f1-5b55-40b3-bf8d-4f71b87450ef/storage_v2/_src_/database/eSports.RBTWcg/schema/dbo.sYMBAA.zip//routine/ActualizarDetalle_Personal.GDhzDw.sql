
--Actualizar
CREATE PROCEDURE ActualizarDetalle_Personal
	@IdPersonal int, @IdTorneo int, @FechaInicioContrato datetime = NULL,@FechaFinContrato datetime = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE DETALLE_PERSONAL
    SET FechaInicioContrato=ISNULL(@FechaInicioContrato,FechaInicioContrato), 
        FechaFinContrato=ISNULL(@FechaFinContrato,FechaFinContrato)
    WHERE IdPersonal=@IdPersonal AND IdTorneo = @IdTorneo
END
go

