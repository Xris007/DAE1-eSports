
--4. Equipo
--Listar
CREATE PROCEDURE ListarEquipo AS
SELECT * FROM EQUIPO
go

