
--3. Juego
--Listar
CREATE PROCEDURE ListarJuego AS
SELECT * FROM JUEGO

