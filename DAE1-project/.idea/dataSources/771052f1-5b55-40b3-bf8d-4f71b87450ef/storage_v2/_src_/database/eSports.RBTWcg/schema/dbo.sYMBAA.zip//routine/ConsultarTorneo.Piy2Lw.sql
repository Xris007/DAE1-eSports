
--Consultar
CREATE PROCEDURE ConsultarTorneo
@IdTorneo INT
AS
SELECT * FROM TORNEO WHERE IdTorneo = @IdTorneo
go

