
--1. Personal
--Listar
CREATE PROCEDURE ListarPersonal AS
SELECT * FROM PERSONAL
go

