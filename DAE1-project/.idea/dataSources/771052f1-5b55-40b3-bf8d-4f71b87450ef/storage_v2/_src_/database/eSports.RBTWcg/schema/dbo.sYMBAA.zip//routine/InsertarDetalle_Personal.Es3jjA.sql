
--Insertar
CREATE PROCEDURE InsertarDetalle_Personal
@IdPersonal int, @IdTorneo int, @FechaInicioContrato datetime,@FechaFinContrato datetime
AS
Insert into DETALLE_PERSONAL values (@IdPersonal,@IdTorneo,@FechaInicioContrato,@FechaFinContrato)
go

