
--Insertar
CREATE PROCEDURE InsertarJugador
@IdJugador int, @ApeJugador varchar(30), @NomJugador varchar(30),@NickJugador varchar(30),@EdadJugador int, @PaisJugador varchar(30),@CapJugador char(1),@IdEquipo int
AS
Insert into JUGADOR values (@IdJugador,@ApeJugador,@NomJugador,@NickJugador,@EdadJugador,@PaisJugador,@CapJugador,@IdEquipo)
go

