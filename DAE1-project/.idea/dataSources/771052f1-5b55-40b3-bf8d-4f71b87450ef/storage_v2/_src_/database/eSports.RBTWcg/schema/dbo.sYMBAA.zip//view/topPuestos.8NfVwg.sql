
---4. estadísticas de los torneos con puestos
create view dbo.topPuestos
as
select DETALLE_EQUIPO.Puesto, EQUIPO.NomEquipo as [Nombre de Equipo], DETALLE_EQUIPO.Victorias, DETALLE_EQUIPO.Derrotas, TORNEO.NomTorneo
from DETALLE_EQUIPO
inner join EQUIPO on DETALLE_EQUIPO.IdEquipo = EQUIPO.IdEquipo
inner join TORNEO on TORNEO.IdTorneo = DETALLE_EQUIPO.IdTorneo
go

