
--Insertar
CREATE PROCEDURE InsertarPersonal
@IdPersonal INT, @ApePersonal VARCHAR(30), @NomPersonal varchar(30), @PaisPersonal varchar(30), @CargoPersonal varchar(30)
AS
Insert into PERSONAL values (@IdPersonal, @ApePersonal,@NomPersonal,@PaisPersonal,@CargoPersonal)
go

