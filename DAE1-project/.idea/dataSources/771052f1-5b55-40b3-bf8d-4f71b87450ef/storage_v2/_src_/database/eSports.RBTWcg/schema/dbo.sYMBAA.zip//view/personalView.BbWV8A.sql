

---5. personal por nombres, cargo y país.
create view dbo.personalView
as
select PERSONAL.ApePersonal + ', ' + PERSONAL.NomPersonal as [Apellidos y Nombres], PERSONAL.CargoPersonal as Cargo, PERSONAL.PaisPersonal as País
from PERSONAL
go

