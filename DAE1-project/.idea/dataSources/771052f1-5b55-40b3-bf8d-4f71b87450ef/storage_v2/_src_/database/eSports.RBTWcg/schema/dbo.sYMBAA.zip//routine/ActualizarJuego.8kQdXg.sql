
--Actualizar 
CREATE PROCEDURE ActualizarJuego
    @IdJuego int, @NomJuego varchar(30) = NULL, @DesaJuego varchar(30) = NULL, @FechaJuego datetime = NULL, @GeneJuego varchar(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE JUEGO
    SET NomJuego=ISNULL(@NomJuego,NomJuego), 
        DesaJuego=ISNULL(@DesaJuego,DesaJuego), 
        FechaJuego=ISNULL(@FechaJuego, FechaJuego),
		GeneJuego=ISNULL(@GeneJuego, GeneJuego)
		
    WHERE IdJuego=@IdJuego
END

EXEC ActualizarJuego @idjuego = 10, @nomjuego = 'game'
go

