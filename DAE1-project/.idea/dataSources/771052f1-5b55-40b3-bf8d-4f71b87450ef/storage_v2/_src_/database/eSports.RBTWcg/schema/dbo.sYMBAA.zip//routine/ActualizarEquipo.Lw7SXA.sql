
--Actualizar 
CREATE PROCEDURE ActualizarEquipo
   @IdEquipo int, @NomEquipo varchar(30) = NULL, @PaisEquipo varchar(30) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE EQUIPO
    SET NomEquipo=ISNULL(@NomEquipo,NomEquipo), 
        PaisEquipo=ISNULL(@PaisEquipo,PaisEquipo)
    WHERE IdEquipo=@IdEquipo
END
go

