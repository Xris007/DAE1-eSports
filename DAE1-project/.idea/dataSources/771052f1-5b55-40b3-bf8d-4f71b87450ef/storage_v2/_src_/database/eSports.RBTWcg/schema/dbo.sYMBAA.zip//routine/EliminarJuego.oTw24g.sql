
--Eliminar
CREATE PROCEDURE EliminarJuego
@IdJuego INT
AS
DELETE FROM JUEGO WHERE IdJuego = @IdJuego

