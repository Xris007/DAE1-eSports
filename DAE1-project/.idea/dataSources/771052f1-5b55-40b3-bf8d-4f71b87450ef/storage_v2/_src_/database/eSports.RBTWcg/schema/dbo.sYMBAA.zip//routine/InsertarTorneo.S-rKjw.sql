
--Insertar
CREATE PROCEDURE InsertarTorneo
@IdTorneo int, @NomTorneo varchar(30), @OrgTorneo varchar(30), @PaisTorneo varchar(30), @LugarTorneo varchar(30), @FechaInicioTorneo datetime, @FechaFinTorneo datetime, @IdJuego int
AS
Insert into TORNEO values (@IdTorneo, @NomTorneo,@OrgTorneo,@PaisTorneo,@LugarTorneo,@FechaInicioTorneo,@FechaFinTorneo,@IdJuego)
go

