
--Eliminar
CREATE PROCEDURE EliminarPersonal
@IdPersonal INT
AS
DELETE FROM PERSONAL WHERE IdPersonal = @IdPersonal
go

